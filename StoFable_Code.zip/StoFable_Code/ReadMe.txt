The package is for the following paper:
    Jevgenijs Steinbuks, Yongyang Cai, Jonas Jaegermeyr, Thomas Hertel. Assessing Effects of Climate and Technology Uncertainties in Large Natural Resource Allocation Problems.

LandUse_Det.gms is for solving the deterministic version of the dynamic stoachastic model.

LandUse_Sto.gms applies the SCEQ method (Cai and Judd, 2021) to solve the dynamic stoachastic model. It requires an argument input: seedv, which is the seed for generating random numbers. When using multiple cores in parallel, the value of seedv should be different across cores. The current version generates 120 simulated paths for each core (specified in the line "set nsim /1*120/"), but you can change the number to be larger or smaller, depending on how many cores you use in parallel and how many total number of simulation paths you want to generate. 

LandUse_Sto_errCheck.gms does the same job of LandUse_Sto.gms, but it also provides accuracy checking accuracy of the solution from SCEQ. This will consume much more computational time than LandUse_Sto.gms. Readers may revise it to have a simpler and faster accuracy check for SCEQ (e.g., just check several periods or several simulated paths), see Cai and Judd (2021).

If readers have any questions, please contact Yongyang Cai at cai.619@osu.edu. 


References:

Cai, Yongyang, and Kenneth Judd (2021). A Simple but Powerful Simulated Certainty Equivalent Approximation Method for Dynamic Stochastic Problems. NBER working paper 28502. 